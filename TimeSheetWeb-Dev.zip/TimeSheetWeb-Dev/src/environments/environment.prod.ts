export const environment = {
  production: true,
  apiUrl : "https://localhost:44391/api/v1",
  baseUrl : "https://localhost:44391/api"
};
